﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebAssignemnt.Pages
{
    public class DisplayBlogModel : PageModel
    {

        


        public void OnGet()
        {
            
        }
    }
}
